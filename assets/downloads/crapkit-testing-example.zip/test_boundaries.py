import pytest
from calc.grade import grade, summarize
from calc.parse import coerce, read_row, parse
from calc.report import tally, render, banner

@pytest.mark.parametrize("value,expected", [("",None),("  ",None),("-2",-2),("1.5",1.5),("alpha","alpha")])
def test_coerce_boundaries(value, expected):
    assert coerce(value) == expected

@pytest.mark.parametrize("line", ["", "# comment"])
def test_skip_non_rows(line):
    assert read_row(line, ["name", "score"]) is None

def test_wrong_column_count():
    with pytest.raises(ValueError):
        read_row("a,1,extra", ["name", "score"])

def test_missing_score_defaults_to_zero():
    assert read_row("a,", ["name", "score"]) == {"name":"a", "score":0}

def test_empty_input():
    assert parse("", ["name", "score"]) == []

@pytest.mark.parametrize("score,expected", [(90,"A"),(89,"B"),(80,"B"),(79,"C"),(70,"C"),(69,"D"),(60,"D"),(59,"F")])
def test_grade_boundaries(score, expected):
    assert grade(score) == expected

def test_summarize_counts_and_empty_input():
    assert summarize([]) == {}
    assert summarize([{"score":90},{"score":90},{"score":59}]) == {"A":2,"F":1}

def test_tally_boundaries_and_empty_input():
    assert tally([],40,90) == {"low":0,"mid":0,"high":0}
    assert tally([{"score":40},{"score":90}],40,90) == {"low":0,"mid":1,"high":1}

def test_render_missing_buckets():
    assert render({},3) == " low  0\n mid  0\nhigh  0"

@pytest.mark.parametrize("bins,total,expected", [({"high":0},0,"no rows"),({"high":2},3,"most rows are high"),({"high":1},4,"25% of rows are high"),({"high":0},3,"nothing high")])
def test_banner_branches(bins,total,expected):
    assert banner(bins,total) == expected
