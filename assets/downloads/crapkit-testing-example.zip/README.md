# Adding boundary tests: a small Crapkit teaching example

This package contains a public Python fixture, its four original tests, 25 added
test cases, a runner and the measured results. The implementation is unchanged.
It illustrates how Crapkit's coverage-aware score responds to additional tests;
it is not a production, productivity, maintainability or defect-reduction study.
Full measured coverage does not prove that assertions are strong or code correct.

Source and tool revision (MIT):
https://github.com/JeanFrancoisGagne/crapkit/tree/8ff0fab87899fa43072df9a305861c96754962e3/tools/demo/fixture

Measured September 20, 2026 with Python 3.11 on Windows. The runner is written for
Python 3.11+ and Git; results are compared against the exact published fixture.
Dependencies are pinned in requirements-reproduce.txt. Download/install happens
only when you explicitly run pip, not from the reproduction runner.

## Reproduce in an environment you choose

Extract this package. Create a fresh environment using your preferred tooling.
For example, on Windows:

```
python -m venv .venv
.venv/Scripts/python -m pip install -r requirements-reproduce.txt
.venv/Scripts/python reproduce.py --output results
```

On macOS/Linux:

```
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements-reproduce.txt
.venv/bin/python reproduce.py --output results
```

The runner refuses an existing output directory. It copies the bundled fixture,
creates a local Git repository, runs the original tests, adds the supplied boundary
tests, and measures again. It never deletes a directory, installs dependencies,
edits your global Git configuration or contacts a remote Git repository.
The two teaching commits use an explicitly fictional .invalid email address.

The coverage lane in both phases runs:

```
python -m pytest --cov=calc --cov-branch --cov-report=json:.crapkit/cov/py.json --junitxml=.crapkit/cov/tests.xml
python -m crapkit coverage --repo . --export before.tsv --json
```

The second phase uses `after.tsv`. Actual commands use the interpreter running
reproduce.py, keeping the test lane in the selected environment. Runner outputs
include relative-path TSV/CSV measurements, sanitized results.json, and local
Git/coverage files used in the run. Do not publish a raw run directory blindly.

## Reading the result

- Eight functions are measured in both phases; cyclomatic complexity is unchanged.
- Passing test cases: 4 to 29. Every measured function reaches 100% coverage.
- Sum of function CRAP scores (Crapkit's `crap_load`): 60.26 to 29.00.
- Functions above the configured target of 6: 3 to 0.
- Coverage is branch coverage within the function; functions without branches
  use line coverage. CSV coverage values are fractions, not percentages.
- Formula: `CRAP = complexity^2 * (1 - coverage)^3 + complexity`.

The CRAP metric predates Crapkit: Alberto Savoia and Bob Evans introduced it in
2007. Crapkit provides the measurement and workflow tooling. Its `crap_load`
here is a sum of function scores, not the original crap4j workload estimator.
See https://www.artima.com/weblogs/viewpost.jsp?thread=215899 and the pinned
Crapkit README for attribution, semantics and limitations.

This package contains only the public fixture, additional tests, MIT license,
portable runner, pinned requirements and reviewed results. It contains no private
project, credentials, original execution logs or source-repository history.
