"""Run the bundled public teaching fixture in a NEW output directory.

Install requirements-reproduce.txt in an environment you choose first.
This runner installs nothing and never removes or overwrites an output directory.
"""
import argparse
import csv
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
EXPECTED = json.loads((HERE / 'expected-results.json').read_text(encoding='utf-8'))


def run(command, cwd):
    result = subprocess.run(command, cwd=cwd, capture_output=True, text=True,
                            encoding='utf-8', env={**os.environ, 'PYTHONUTF8': '1'})
    if result.returncode:
        raise RuntimeError('Command failed: ' + str(command[0]) + '\n' + result.stderr + result.stdout)
    return result.stdout


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, required=True, help='New directory for the fixture and results')
    args = p.parse_args()
    output = args.output.resolve()
    if output.exists():
        raise SystemExit('Output already exists; choose a new directory. Nothing was changed.')
    if sys.version_info < (3, 11):
        raise SystemExit('Use Python 3.11 or newer.')
    try:
        distribution = importlib.metadata.distribution('crapkit')
        direct = json.loads(distribution.read_text('direct_url.json') or '{}')
        if direct.get('vcs_info', {}).get('commit_id') != EXPECTED['source_revision']:
            raise ValueError('Install the exact public Git revision from requirements-reproduce.txt.')
        for package, version in [('lizard', '1.24.0'), ('coverage', '7.16.1'), ('pytest', '9.1.1'), ('pytest-cov', '7.1.0')]:
            if importlib.metadata.version(package) != version:
                raise ValueError('Unexpected dependency: ' + package + '; use the supplied requirements.')
    except (importlib.metadata.PackageNotFoundError, ValueError) as exc:
        raise SystemExit(str(exc))
    if not shutil.which('git'):
        raise SystemExit('Git is required to track the two local fixture revisions.')
    for name, digest in EXPECTED['source_hashes'].items():
        if hashlib.sha256((HERE / 'fixture' / name).read_bytes()).hexdigest() != digest:
            raise SystemExit('Bundled implementation differs from the reviewed public fixture: ' + name)
    shutil.copytree(HERE / 'fixture', output)
    run(['git', '-c', 'core.autocrlf=false', 'init', '-b', 'main'], output)
    # Override identity and signing only for these teaching commits, not user config.
    commit = ['git', '-c', 'user.name=Teaching fixture', '-c', 'user.email=fixture@example.invalid',
              '-c', 'commit.gpgsign=false', '-c', 'core.autocrlf=false']
    run(commit + ['add', 'calc', 'tests', 'pyproject.toml'], output)
    run(commit + ['commit', '-m', 'Public fixture baseline'], output)
    command = '"' + sys.executable.replace('\\', '/') + '" -m pytest --cov=calc --cov-branch --cov-report=json:.crapkit/cov/py.json --junitxml=.crapkit/cov/tests.xml'
    config = '[crapkit]\ntarget = 6\n\n[[scope]]\nname = "calc"\npaths = ["calc"]\nlanguages = ["python"]\n\n[[lane]]\nname = "py"\ncommand = ' + json.dumps(command) + '\nartifact = ".crapkit/cov/py.json"\nresults_artifact = ".crapkit/cov/tests.xml"\nparser = "coveragepy"\nscopes = ["calc"]\n'
    (output / 'crapkit.toml').write_text(config, encoding='utf-8')
    summaries, rows = {}, {}
    for phase in ['before', 'after']:
        if phase == 'after':
            shutil.copyfile(HERE / 'test_boundaries.py', output / 'tests/test_boundaries.py')
            run(commit + ['add', 'tests/test_boundaries.py'], output)
            run(commit + ['commit', '-m', 'Add boundary tests; retain implementation'], output)
        result = json.loads(run([sys.executable, '-m', 'crapkit', 'coverage', '--repo', str(output),
                                 '--export', phase + '.tsv', '--json'], output))
        summaries[phase] = {'tests': result['lanes']['py']['tests_total'], 'functions': result['functions'],
                            'over_target': result['over_target'], 'crap_load': result['crap_load']}
        with (output / (phase + '.tsv')).open(encoding='utf-8', newline='') as stream:
            rows[phase] = list(csv.DictReader(stream, delimiter='\t'))
    combined = []
    for before, after in zip(rows['before'], rows['after'], strict=True):
        if (before['path'], before['long_name'], before['ccn']) != (after['path'], after['long_name'], after['ccn']):
            raise RuntimeError('Measured implementation changed between phases.')
        combined.append({'path': before['path'], 'function': before['long_name'], 'complexity': int(before['ccn']),
                         'coverage_before': float(before['cov']), 'coverage_after': float(after['cov']),
                         'crap_before': float(before['crap']), 'crap_after': float(after['crap'])})
    for name, digest in EXPECTED['source_hashes'].items():
        if hashlib.sha256((output / name).read_bytes()).hexdigest() != digest:
            raise RuntimeError('Fixture implementation changed: ' + name)
    sanitized = {'source_revision': EXPECTED['source_revision'], 'summary': summaries,
                 'functions': combined, 'matches_published_example': summaries == EXPECTED['summary'] and combined == EXPECTED['functions']}
    (output / 'results.json').write_text(json.dumps(sanitized, indent=2) + '\n', encoding='utf-8')
    with (output / 'results.csv').open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(combined[0])); writer.writeheader(); writer.writerows(combined)
    print(json.dumps(sanitized, indent=2))
    if not sanitized['matches_published_example']:
        raise SystemExit('Measured results differ; inspect the outputs before drawing conclusions.')


if __name__ == '__main__':
    main()
